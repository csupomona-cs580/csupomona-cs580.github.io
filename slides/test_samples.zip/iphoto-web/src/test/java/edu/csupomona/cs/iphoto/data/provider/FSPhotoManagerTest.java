package edu.csupomona.cs.iphoto.data.provider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;

public class FSPhotoManagerTest {

	private PhotoManager photoManager = new FSPhotoManager();
	
	@Test
	public void testAddNewPhoto() throws FileNotFoundException {		 
		String filePath = getClass().getResource("/test-image/construction.jpg").getFile();
		File testFile = new File(filePath);
		
		List<String> photoFilesBeforeAdding = photoManager.listUserPhotos("testId001");
		
		photoManager.addNewPhoto("testId001", new FileInputStream(testFile));
		
		List<String> photoFilesAfterAdding = photoManager.listUserPhotos("testId001");
		
		Assert.assertEquals(photoFilesAfterAdding.size(), photoFilesBeforeAdding.size() + 1);
		for(String name : photoFilesBeforeAdding) {
			photoFilesAfterAdding.remove(name);
		}
		Assert.assertEquals(1, photoFilesAfterAdding.size());
		
		String targetFileName = photoFilesAfterAdding.get(0);
		
		File targetFile = photoManager.getPhotoFile("testId001", targetFileName);
		
		Assert.assertEquals(targetFile.length(), testFile.length());
	}
	
	@Test(expected = RuntimeException.class)
	public void testGetPhotoFile() {		
		File file = photoManager.getPhotoFile("testid", "non-existing");		
	}
}






