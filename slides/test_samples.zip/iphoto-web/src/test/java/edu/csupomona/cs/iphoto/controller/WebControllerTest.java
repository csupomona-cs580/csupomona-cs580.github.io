package edu.csupomona.cs.iphoto.controller;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.junit.Test;

import edu.csupomona.cs.iphoto.data.provider.FSPhotoManager;
import edu.csupomona.cs.iphoto.data.provider.FSUserManager;
import edu.csupomona.cs.iphoto.data.provider.PhotoManager;
import edu.csupomona.cs.iphoto.data.provider.UserManager;

public class WebControllerTest {

	@Test
	public void testGetFilteredPhoto() throws FileNotFoundException, IOException {
		String filePath = getClass().getResource("/test-image/construction.jpg").getFile();
		File testFile = new File(filePath);
		
		UserManager userManager = new FSUserManager();
		PhotoManager photoManager = mock(FSPhotoManager.class);
		
		when(photoManager.getPhotoFile(
				"testId", "testphoto", "invert-rotate")).thenReturn(testFile);
		
		WebController webController = new WebController(userManager, photoManager);
		
		HttpServletResponse response = mock(HttpServletResponse.class);
		ServletOutputStream outputStream = mock(ServletOutputStream.class);
		
		when(response.getOutputStream()).thenReturn(outputStream);
		webController.getFilteredPhoto("testId", "testphoto", "invert-rotate", response);
		
		verify(response).setContentType("image/jpeg");
		verify(response).flushBuffer();		
	}
}
