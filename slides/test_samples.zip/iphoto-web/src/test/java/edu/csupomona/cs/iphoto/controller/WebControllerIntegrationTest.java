package edu.csupomona.cs.iphoto.controller;

import java.io.File;
import java.util.List;

import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.IntegrationTest;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.boot.test.TestRestTemplate;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;

import edu.csupomona.cs.iphoto.App;

@RunWith (SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration (classes = App.class)
@WebAppConfiguration
@IntegrationTest
public class WebControllerIntegrationTest {

	@Test
	public void testPing() {
		RestTemplate rest = new TestRestTemplate();
		
		ResponseEntity<String> response = 
				rest.getForEntity("http://localhost:8080/iphoto/ping", String.class);
		
		Assert.assertEquals("OK", response.getBody());
	}
	
	@Test
	public void testAddNewPhoto() {
		RestTemplate rest = new TestRestTemplate();
		
		// get original number of files
		ResponseEntity<List> photoIdsResponse = rest.getForEntity("http://localhost:8080/iphoto/testuser/photos", List.class);
		int size = photoIdsResponse.getBody().size();

		
		String filePath = getClass().getResource("/test-image/construction.jpg").getFile();
		File testFile = new File(filePath);
		
		MultiValueMap<String, Object> requestMap = new LinkedMultiValueMap<String, Object>();
		requestMap.add("photoFile", new FileSystemResource(testFile));
		
		ResponseEntity<Void> response = 
				rest.postForEntity("http://localhost:8080/iphoto/testuser/photo",
						requestMap,
						Void.class);
		
		Assert.assertEquals(response.getStatusCode(), HttpStatus.OK);
		
        photoIdsResponse = rest.getForEntity("http://localhost:8080/iphoto/testuser/photos", List.class);
        Assert.assertEquals(size + 1, photoIdsResponse.getBody().size());
	}
}
