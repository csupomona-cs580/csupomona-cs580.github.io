package edu.csupomona.cs.iphoto.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;

import edu.csupomona.cs.iphoto.App;
import edu.csupomona.cs.iphoto.data.User;
import edu.csupomona.cs.iphoto.data.provider.UserManager;
import edu.csupomona.cs.iphoto.util.CloudWatchFactory;


/**
 * This is the controller used by Spring framework.
 * <p>
 * The basic function of this controller is to map
 * each HTTP API Path to the correspondent method.
 *
 */

@RestController
public class WebController {

	private static Logger logger =
			LoggerFactory.getLogger(WebController.class);

	/**
	 * When the class instance is annotated with
	 * {@link Autowired}, it will be looking for the actual
	 * instance from the defined beans.
	 * <p>
	 * In our project, all the beans are defined in
	 * the {@link App} class.
	 */
    @Autowired
    private UserManager userManager;

    /**
     * This is a simple example of how the HTTP API works.
     * It returns a String "OK" in the HTTP response.
     * To try it, run the web application locally,
     * in your web browser, type the link:
     * 	http://localhost:8080/iphoto/ping
     */
    @RequestMapping(value = "/iphoto/ping", method = RequestMethod.GET)
    String healthCheck() {
    	// TODO: Replace the following return with your name with your GitHub ID
    	// in the exact format: Name (GitHubID)
    	// For instance,
    	// return "John Smith (smithj01)";
    	// Then, run the application locally and check your changes
    	// with the URL: http://localhost:8080/
        return "This is a Jenkins Demo in CS580";
    }

    /**
     * This is a simple example of how to use a data manager
     * to retrieve the data and return it as an HTTP response.
     * <p>
     * Note, when it returns from the Spring, it will be
     * automatically converted to JSON format.
     * <p>
     * Try it in your web browser:
     * 	http://localhost:8080/iphoto/user101
     */
    @RequestMapping(value = "/iphoto/{userId}", method = RequestMethod.GET)
    User getUser(@PathVariable("userId") String userId) {
    		long startTime = System.currentTimeMillis();
    		logger.info("Get user information for " + userId);

    		User user = null;
    		try {
    			user = userManager.getUser(userId);
    			long duration = System.currentTimeMillis() - startTime;
        		CloudWatchFactory.get().publishAPIMetrics("iphoto/user", duration, true);
    		} catch (Exception e) {
    			logger.error("Failed to get the user info for " + userId, e);
    			long duration = System.currentTimeMillis() - startTime;
    			CloudWatchFactory.get().publishAPIMetrics("iphoto/user", duration, false);
    		}
        return user;
    }



    /*********** Photo Management (TODO in Assignment 4) **********/
    // The following methods provide the basic functionalities
    // to add (upload), get, list and delete photos.

    @RequestMapping(value = "/iphoto/{userId}/photo", method = RequestMethod.POST)
    void addPhoto(
            @PathVariable("userId") String userId,
            @RequestParam("photoFile") MultipartFile file,
            HttpServletResponse response) throws IOException {

    	// TODO
    }

    @RequestMapping(value = "/iphoto/{userId}/photo/{photoId}", method = RequestMethod.GET)
    void getPhoto(
            @PathVariable("userId") String userId,
            @PathVariable("photoId") String photoId,
            HttpServletResponse response) {

    	// TODO
    }

    @RequestMapping(value = "/iphoto/{userId}/photos", method = RequestMethod.GET)
    List<String> listPhotos(@PathVariable("userId") String userId) {

        // TODO
    	return null;
    }

    @RequestMapping(value = "/iphoto/{userId}/photo/{photoId}", method = RequestMethod.DELETE)
    String deletePhoto(
            @PathVariable("userId") String userId,
            @PathVariable("photoId") String photoId) {

    	// TODO
        return "OK";
    }


    /*********** Photo Filter (TODO in Assignment 5) **********/
    // The following methods handles listing available
    // photo filters, as well as applying the filters
    // to the given photo.

    @RequestMapping(value = "/iphoto/filters/list", method = RequestMethod.GET)
    List<String> getAvailableFilters() {

    	// TODO
        return null;
    }

    @RequestMapping(value = "/iphoto/{userId}/photo/{photoId}/filter/{filters}", method = RequestMethod.GET)
    void getFilteredPhoto(
            @PathVariable("userId") String userId,
            @PathVariable("photoId") String photoId,
            @PathVariable("filters") String filters,
            HttpServletResponse response) {

    	// TODO
    }


    /*********** User Follow Management (TODO in Assignment 5) **********/
    // The following methods handle following and unfollowing
    // other users.

    @RequestMapping(value = "/iphoto/{userId}/follow/{followedUserId}", method = RequestMethod.POST)
    String followUser(
    		@PathVariable("userId") String userId,
            @PathVariable("followedUserId") String followedUserId) {

        // TODO
        return "OK";
    }

    @RequestMapping(value = "/iphoto/{userId}/unfollow/{followedUserId}", method = RequestMethod.POST)
    String unfollowUser(
    		@PathVariable("userId") String userId,
            @PathVariable("followedUserId") String followedUserId) {

    	// TODO
        return "OK";
    }



    /*********** Web UI Test Utility **********/
    /**
     * This method provide a simple web UI for you to test the different
     * functionalities used in this web service.
     */
    @RequestMapping(value = "/iphoto/{userId}/home", method = RequestMethod.GET)
    ModelAndView getUserHomepage(@PathVariable("userId") String userId) {
        ModelAndView modelAndView = new ModelAndView("home");
        //modelAndView.addObject("user", getUser(userId));
        modelAndView.addObject("photos", listPhotos(userId));
        modelAndView.addObject("filters", getAvailableFilters());
        return modelAndView;
    }

}